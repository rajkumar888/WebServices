package com.everest.webservice.spi;

import org.testng.asserts.SoftAssert;
import org.xframium.device.ng.AbstractSeleniumTest;
import org.xframium.page.PageManager;

import com.everest.webservice.WebService;


public class PageImplInvoker extends AbstractSeleniumTest{
	
/**************************************************/
	
	SoftAssert softAssert= new SoftAssert();
	
	public void createSubmission(String loginId,String loginSource, String password,String tcID) throws Exception
 	{
   		
 		WebService objReference = (WebService) PageManager.instance().createPage( WebService.class, getWebDriver());
 		objReference.login(loginId,loginSource,password,tcID, softAssert);
 	}
	
	
}
