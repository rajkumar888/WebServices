package demo;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class DemoOthers {

	WebDriver driver;
	
	//@Test
	public static void screenshot() 
	{
		DateFormat df = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		String folder=df.format(new Date());
		
		String path="D:\\selenium\\"+folder;
		
		System.out.println(path);
		 System.out.println(System.getProperty("user.dir"));
	}

	//@Test
	public void loginin() throws InterruptedException{
		//System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe"); 
		driver= new ChromeDriver();
		driver.get("https://www.google.com");

		String w1=driver.getWindowHandle();

		System.out.println(w1);
		
		Actions act=new Actions(driver);

		List <WebElement> abc=driver.findElements(By.tagName("a"));
		
		for(WebElement abc1: abc){
			act.keyDown(Keys.CONTROL).click(abc1).keyUp(Keys.CONTROL).build().perform();
			
			Set<String> ll=driver.getWindowHandles();
			
			Thread.sleep(3000);
			
			for(String l2:ll){
				if(!l2.equals(w1))
						{
					driver.switchTo().window(l2);
					System.out.println(driver.getTitle());
					driver.close();
					break;
				}
			}
			driver.switchTo().window(w1);
			
		}
	}
	
	@Test
	public void hello()
	{
		try {
			int x=110/0;
		}
		
		finally
		{
			System.out.println("exeption found");
		}
				System.out.println("normal termination ");
	}
}
