package demo;

import java.io.IOException;
import static com.jayway.restassured.RestAssured.given;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.Test;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;


public class WebServiceTesting2 {
	
	@Test()
	public void test1() {
		
		System.out.println("\nTest Case 1\n");
		
		RequestSpecification requestSpecification=RestAssured.given();

		requestSpecification.header("Authorization","Q2xlYXJPRkFDU2VydmljZTtDbGVhck9GQUM7RVNCRGV2VXNlcjtFU0I7MS4wO0V4Y2Vzc0dMX0RldjY=");

		requestSpecification.headers("content-type","application/json");

		requestSpecification.body("{\"ESCAPEREST\":{\"Account\":{\"InsuredName\":\"Dawood Ibrahim\"}}}");
			
		Response response=requestSpecification.post("http://esbdev:7802/service/GenericRestClearOFACService");
		
		System.out.println(response.getStatusCode());		
		System.out.println(response.asString());
	}
	
	@Test
	public void test2() {
		System.out.println("\nTest Case 2\n");
		
		RequestSpecification requestSpecification=RestAssured.given();
		
		requestSpecification.header("Authorization","Q2xlYXJTdWJtaXNzaW9uU2VydmljZTtDbGVhclN1Ym1pc3Npb247RVNVSW50VXNlcjtFU1U7MS4w");
		
		requestSpecification.headers("content-type","application/xml");
		requestSpecification.body("D:\\Users\\rsingh\\Desktop\\PayLoad.xml");
	
		Response response = requestSpecification.post("https://esbdev.everestre.net:7843/services/GenericUpdateSubmissionService/2.0");
		System.out.println(response.getStatusCode());	
		System.out.println(response.asString());
	}

}
