package com.everest.webservice.clearsubmission;

import org.testng.asserts.SoftAssert;
import org.xframium.page.Page;
import org.xframium.page.Page.ElementDefinition;
import org.xframium.page.Page.ScreenShot;
import org.xframium.page.Page.TimeMethod;

public interface WebServiceClearSubmission extends Page {

	
	@TimeMethod
	@ScreenShot
	public void clearOFACService(String tcID, SoftAssert softAs) throws Exception;
	public void updateSubmission(String tcID, SoftAssert softAs) throws Exception;


}
