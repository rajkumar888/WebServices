package com.everest.webservice.clearsubmission.spi;

import org.testng.asserts.SoftAssert;
import org.xframium.device.ng.AbstractSeleniumTest;
import org.xframium.page.PageManager;

import com.everest.webservice.WebService;
import com.everest.webservice.clearsubmission.WebServiceClearSubmission;


public class ClearSubmissionImplInvoker extends AbstractSeleniumTest{
	
/**************************************************/
	
	SoftAssert softAssert= new SoftAssert();
	
	public void clearOFACService(String tcID) throws Exception
 	{
   		
 		WebServiceClearSubmission objReference = (WebServiceClearSubmission) PageManager.instance().createPage( WebServiceClearSubmission.class, getWebDriver());
 		objReference.clearOFACService(tcID, softAssert);
 		//objReference.clearSubmission2(tcID, softAssert);
 	}
	
	public void updateSubmission(String tcID) throws Exception
 	{
   		
 		WebServiceClearSubmission objReference = (WebServiceClearSubmission) PageManager.instance().createPage( WebServiceClearSubmission.class, getWebDriver());
 		objReference.updateSubmission(tcID, softAssert);
 		//objReference.clearSubmission2(tcID, softAssert);
 	}
	
	
}
