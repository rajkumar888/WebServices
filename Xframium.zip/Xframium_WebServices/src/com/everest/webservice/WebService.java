package com.everest.webservice;

import org.testng.asserts.SoftAssert;
import org.xframium.page.Page;
import org.xframium.page.Page.ElementDefinition;
import org.xframium.page.Page.ScreenShot;
import org.xframium.page.Page.TimeMethod;

public interface WebService extends Page {

	
	@TimeMethod
	@ScreenShot
	public void login(String loginId,String loginSource, String password,String tcID, SoftAssert softAs) throws Exception;


}
