package demo;

import java.io.IOException;
import static com.jayway.restassured.RestAssured.given;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.testng.annotations.Test;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

public class WebServiceTesting4 {

	@Test()
	public void test1() {

		System.out.println("\nTest Case 1\n");
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.header("Authorization",
				"Q2xlYXJPRkFDU2VydmljZTtDbGVhck9GQUM7RVNCRGV2VXNlcjtFU0I7MS4wO0V4Y2Vzc0dMX0RldjY=");
		requestSpecification.headers("content-type", "application/json");
		requestSpecification.body("{\"ESCAPEREST\":{\"Account\":{\"InsuredName\":\"Dawood Ibrahim\"}}}");
		
		Response response = requestSpecification.post("http://esbdev:7802/service/GenericRestClearOFACService");
		System.out.println(response.getStatusCode());
		System.out.println(response.asString());
	}
}
