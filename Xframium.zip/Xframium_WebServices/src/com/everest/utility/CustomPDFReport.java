package com.everest.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.xframium.artifact.ArtifactTime;
import org.xframium.artifact.ArtifactType;
import org.xframium.device.artifact.Artifact;
import org.xframium.device.artifact.ArtifactProducer;
import org.xframium.device.data.DataManager;
import org.xframium.spi.Device;
import org.xframium.spi.RunDetails;

import com.everest.functions.GenericFunctions;
import com.itextpdf.text.Document;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import au.com.bytecode.opencsv.CSVReader;

import org.xframium.device.ConnectedDevice;
import org.xframium.device.DeviceManager;
import org.xframium.device.ng.AbstractSeleniumTest;
//import org.xframium.device.ng.AbstractSeleniumTest.TestContext;
//import org.xframium.device.ng.AbstractSeleniumTest.TestName;
//import org.xframium.device.ng.AbstractSeleniumTest.TestName;
import org.testng.ITestResult;

public class CustomPDFReport extends AbstractSeleniumTest{
	
	private static CustomPDFReport singleton = new CustomPDFReport();
	//ThreadLocal<HashMap<String, ConnectedDevice>> threadDevices = new ThreadLocal<HashMap<String, ConnectedDevice>>();
	// private static ThreadLocal<TestContext> threadContext = new ThreadLocal<TestContext>();
	private CustomPDFReport() {

		}

		public static CustomPDFReport instance() {
			return singleton;
		}
		
	
	    public void createReport(String testName,ITestResult testResult) {
	    	
	    	
	    	//HashMap<String, ConnectedDevice> map = getDevicesToCleanUp();
	        //threadContext.set( null );
	        //Iterator<String> keys = ((map != null) ? map.keySet().iterator() : null);
	        
		String DEFAULT = "default";
		WebDriver webDriver = getWebDriver();
        ConnectedDevice device=getConnectedDevice( DEFAULT );
        String runKey=testName;

        File rootFolder = new File( DataManager.instance().getReportFolder(), RunDetails.instance().getRootFolder() );
        rootFolder.mkdirs();
        
        if ( DataManager.instance().getAutomaticDownloads() != null )
        {
            if ( webDriver instanceof ArtifactProducer )
            {
                if ( DataManager.instance().getReportFolder() == null )
                    DataManager.instance().setReportFolder( new File( "." ) );

                for ( ArtifactType aType : DataManager.instance().getAutomaticDownloads() )
                {
                    if ( aType.getTime() == ArtifactTime.AFTER_TEST )
                    {
                        try
                        {
                            Artifact currentArtifact = ((ArtifactProducer) webDriver).getArtifact( webDriver, aType,  device, runKey, testResult.getStatus() == ITestResult.SUCCESS );
                            if ( currentArtifact != null )
                                currentArtifact.writeToDisk( rootFolder );
                        }
                        catch ( Exception e )
                        {
                            log.error( "Error acquiring Artifacts - " + e );
                        }
                    }
                }
            }	
	     }
	   }
	
	public void generatePDFReport(String strTesCase,String strBrowser,ITestResult testResult ) throws URISyntaxException
    {
		try {
		      
			File directory = new File("./");
			System.out.println(directory.getAbsolutePath());
			String strDirectoryPath =directory.getAbsolutePath().split("\\.") [0];
			String strTestStatus="";

			if (testResult.isSuccess()) {
				strTestStatus="PASS";
			}
			else {
				strTestStatus="FAIL";
			}
			
			String strArtifactpath=DataManager.instance().getReportFolder().getPath()+"\\"+RunDetails.instance().getRootFolder().toString();
			String strCSVFilePath=strDirectoryPath+strArtifactpath+"\\"+strTesCase+"\\"+strBrowser+"\\"+strTesCase+".csv";
			String strPDFPath=strDirectoryPath+strArtifactpath+"\\"+strTesCase+"\\"+strBrowser+"\\"+strTesCase+".pdf";
			
	        CSVReader reader = new CSVReader(new FileReader(strCSVFilePath));
	        /* Variables to loop through the CSV File */
	        String [] nextLine; /* for every line in the file */            
	        int lnNum = 0; /* line number */
	        /* Step-2: Initialize PDF documents - logical objects */
	        Document my_pdf_data = new Document();
	        PdfWriter.getInstance(my_pdf_data, new FileOutputStream(strPDFPath));
	        my_pdf_data.open();  
	        
	        PdfPTable testCase_table=new PdfPTable(2);
	        PdfPCell tesCase_table_cell;
	        tesCase_table_cell=new PdfPCell(new Phrase("TestCase: "+strTesCase));
	        testCase_table.addCell(tesCase_table_cell);
	        
	        tesCase_table_cell=new PdfPCell(new Phrase("Status: "+strTestStatus));
	        testCase_table.addCell(tesCase_table_cell);
	        my_pdf_data.add(testCase_table); 
	        
	        PdfPTable my_first_table = new PdfPTable(6);
	        PdfPCell table_cell;
	        
	        table_cell=new PdfPCell(new Phrase("Page"));
	        my_first_table.addCell(table_cell);
	        table_cell=new PdfPCell(new Phrase("Element"));
	        my_first_table.addCell(table_cell); 
	        table_cell=new PdfPCell(new Phrase("Step"));
	        my_first_table.addCell(table_cell); 
	        table_cell=new PdfPCell(new Phrase("TimeStamp"));
	        my_first_table.addCell(table_cell); 
	        table_cell=new PdfPCell(new Phrase("Time in ms"));
	        my_first_table.addCell(table_cell); 
	        table_cell=new PdfPCell(new Phrase("Status"));
	        my_first_table.addCell(table_cell);
	        /* Step -3: Loop through CSV file and populate data to PDF table */
	        while ((nextLine = reader.readNext()) != null) {
	                lnNum++;        
	                table_cell=new PdfPCell(new Phrase(nextLine[4]));
	                my_first_table.addCell(table_cell);
	                table_cell=new PdfPCell(new Phrase(nextLine[5]));
	                my_first_table.addCell(table_cell); 
	                table_cell=new PdfPCell(new Phrase(nextLine[6]));
	                my_first_table.addCell(table_cell); 
	                table_cell=new PdfPCell(new Phrase(nextLine[7]));
	                my_first_table.addCell(table_cell); 
	                table_cell=new PdfPCell(new Phrase(nextLine[8]));
	                my_first_table.addCell(table_cell); 
	                table_cell=new PdfPCell(new Phrase(nextLine[9]));
	                my_first_table.addCell(table_cell); 
	        }
	        /* Step -4: Attach table to PDF and close the document */
	        my_pdf_data.add(my_first_table);                       
	        my_pdf_data.close(); 
	        
	        System.out.println("PDF report generated successfully");
	        CustomReporting.instance().logReport("<a href=\"" + strPDFPath + "\"" + ">Click here to view the PDF report</a>");
		     } 
		catch (Exception ex )
		    {
			System.out.println(ex);
		    } 
       }
	}
