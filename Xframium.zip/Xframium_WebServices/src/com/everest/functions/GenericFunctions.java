package com.everest.functions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import org.xframium.page.PageManager;
import org.xframium.page.element.Element;
import org.xframium.page.element.provider.ElementProvider;
import org.xframium.page.AbstractPage;
import org.xframium.page.ElementDescriptor;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.security.UserAndPassword;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import org.xframium.device.ng.AbstractSeleniumTest;
//import com.everest.utility.AbstractSeleniumTest;
import org.xframium.exception.XFramiumException;
import org.xframium.exception.XFramiumException.ExceptionType;
import org.xframium.integrations.perfectoMobile.rest.services.Imaging.Resolution;
import org.xframium.page.StepStatus;
import org.xframium.page.element.Element;

import com.everest.utility.CustomAbstractTest;
import com.everest.utility.CustomReporting;
import com.everest.utility.GlobalVariableContainer;
import com.itextpdf.text.Document;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import au.com.bytecode.opencsv.CSVReader;

import java.awt.Desktop;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.openqa.selenium.TakesScreenshot;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.apache.poi.util.Units;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.xframium.device.DeviceManager;

import org.xframium.page.keyWord.spi.KeyWordPageImpl;
import org.xframium.page.AbstractPage;
import com.everest.utility.CustomAbstractPage;
import org.xframium.page.element.AbstractElement;
import org.xframium.page.element.SeleniumElement;

public class GenericFunctions extends AbstractSeleniumTest{
	//KeyWordPageImpl
	
	private String strTokenName;
	private String strTokenValue;
	private FileInputStream pic = null;
	private String screenShotWordDocPath = "";
	private XWPFDocument doc = null;
	private XWPFParagraph p = null;
	private XWPFRun r = null;
	private String reqScreens = "";

	private static GenericFunctions singleton = new GenericFunctions();
	

	private GenericFunctions() {

	}

	public static GenericFunctions instance() {
		return singleton;
	}

	/*******************************************************************
	 * Name : getCustumWebDriver Description : Used to get the webDriver Object
	 * Modification Log : Date Initials Description of Modifications
	 ********************************************************************/
	public WebDriver getCustumWebDriver() {
		return getWebDriver();


		//return CustomFunctions.instance().getCustumWebDriver();

	}

	/*******************************************************************
	 * Name : getCustomPageName Description : Used to get the name of the page
	 * Modification Log : Date Initials Description of Modifications
	 ********************************************************************/
	public String getCustomPageName() {
		return PageManager.instance().getPageCache().toString().split("Impl")[0].split("spi.")[1];
		//return cFun.getCustomPageName();
	}
	
	/*******************************************************************
	 * Name : getCustomElementName Description : Used to get the name of the element
	 * Modification Log : Date Initials Description of Modifications
	 ********************************************************************/
	
	public String getCustomElementName(Element el) {
		//String abc=PageManager.instance().
		//String abc=el.getKey();
		//return el.getKey();
		return el.toString();
		//return cFun.getCustomElementName();
	}

	/*******************************************************************
	 * Name : _setGlobalToken Description : Used to set the token value in
	 * global scope and _addToken function will called before every function
	 * Modification Log : Date Initials Description of Modifications
	 ********************************************************************/
	public void _setGlobalToken(String strTokenName, String strTokenValue) {
		this.strTokenName = strTokenName;
		this.strTokenValue = strTokenValue;
	}

	/*******************************************************************
	 * Name : _addToken Description : Used to to add the token value to an
	 * object in action Modification Log : Date Initials Description of
	 * Modifications
	 ********************************************************************/
	public void _addToken(Element element) {
		element.addToken(this.strTokenName, this.strTokenValue);
	}
	
	/*******************************************************************
	*	Name              :	_addToGlobalVariableList
	*	Description       : Used to add global variable to HashMap
	*   Parameters 		  : strKey - Key Value
	*   				  : strValue - Value
	*	Modification Log  :                                                     
	*	Date		Initials     	Description of Modifications 
	********************************************************************/
	public void _addToGlobalVariableList(String strKey,String strValue)
	{			
		GlobalVariableContainer.instance().addVariable(strKey, strValue);
	}
	
	/*******************************************************************
	*	Name              :	_addToGlobalVariableList
	*	Description       : Used to get global variable value from HashMap
	*   Parameters 		  : strKey - Key Value
	*	Modification Log  :                                                     
	*	Date		Initials     	Description of Modifications 
	********************************************************************/
	public String _getGlobalVariableValue(String strKey)
	{			
		return GlobalVariableContainer.instance().getVariable(strKey);
	}

	/*******************************************************************
	 * Name : _setValue Description : Used to set the value to any object, Only
	 * when there is data in DB Modification Log : Date Initials Description of
	 * Modifications
	 ********************************************************************/
	public void _setValue(Element element, String strValue) {

		long startTime = System.currentTimeMillis();
		try {
			if (!(strValue.isEmpty())) {
				element.setValue(strValue);
				 //WebElement elm = (WebElement) element.getNative();
				// elm.sendKeys(Keys.TAB);
			}

		} catch (Exception ex) {
			// CustomReporting.logReport(keywordPage.getPageName(),element.getNative().toString(),"setValue","",StepStatus.FAILURE,new
			// String[] { strValue },startTime,ex);

			CustomReporting.logReport(getCustomPageName(),getCustomElementName(element), "setValue", "", StepStatus.FAILURE,
					new String[] { strValue }, startTime, ex);
			throw ex;
			/* throw ex; */

		}
	}

	/*******************************************************************
	 * Name : _checkDefaultValue Description : Used to compare the attribute
	 * value of an object Modification Log : Date Initials Description of
	 * Modifications
	 ********************************************************************/
	public void _checkDefaultValue( Element element, String strAttribute, String strExpValue) {
		String strActValue;
		long startTime = System.currentTimeMillis();

		// Get the Attribute value
		
		if(strAttribute.equalsIgnoreCase("TEXT")){
			WebElement ele = (WebElement) element.getNative();
			strActValue=ele.getText().trim();
		}else{
		strActValue = element.getAttribute(strAttribute);
		}

		// Compare the value
		if (!strActValue.equals(strExpValue)) {
			
			//CustomReporting.logReport(getCustomPageName(), element.toString(), "_label", "", StepStatus.FAILURE,
			//		new String[] {}, startTime, null);
			
			CustomReporting.logReport("","", "Expected value: "+strExpValue+" does not match with the actual value: "+strActValue, "", StepStatus.FAILURE,
					new String[] { }, startTime, null);
			throw new RuntimeException();
		     }
			else
			{
				CustomReporting.logReport("","", "Expected value: "+strExpValue+" matches with the actual value: "+strActValue,StepStatus.SUCCESS,new String[] { },startTime);
			}
		

		//assertSoft.assertEquals(strExpValue, strActValue);
	}

	/*******************************************************************
	 * Name : _click Description : Used to click any type of object Modification
	 * Log : Date Initials Description of Modifications
	 ********************************************************************/
	public void _click(Element element) {
		// element.click();

		long startTime = System.currentTimeMillis();
		try {

			element.click();

		} catch (Exception ex) {

			CustomReporting.logReport(getCustomPageName(), element.toString(), "click", "", StepStatus.FAILURE,
					new String[] {}, startTime, ex);
			throw ex;

		}

	}

	/*******************************************************************
	 * Name : _getRelativeDate Description : Used to get the relative date wrt
	 * current date Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/
	public String _getRelativeDate(String strRelation, String intDays, String intMonths, String intYears) {
		DateFormat dateFormate = new SimpleDateFormat("MM/dd/yyyy");
		Date dateTodays = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateTodays);

		if (intDays.isEmpty())
			intDays = "0";

		if (intMonths.isEmpty())
			intMonths = "0";

		if (intYears.isEmpty())
			intYears = "0";

		switch (strRelation.toUpperCase()) {
		case "PAST":
			cal.add(Calendar.DATE, -Integer.parseInt(intDays));
			cal.add(Calendar.MONTH, -Integer.parseInt(intMonths));
			cal.add(Calendar.YEAR, -Integer.parseInt(intYears));
			break;
		case "FUTURE":
			cal.add(Calendar.DATE, Integer.parseInt(intDays));
			cal.add(Calendar.MONTH, Integer.parseInt(intMonths));
			cal.add(Calendar.YEAR, Integer.parseInt(intYears));
			break;

		default:
			break;

		}

		return dateFormate.format(cal.getTime());
	}

	/*******************************************************************
	 * Name : _getRandomString Description : Used to get the relative date wrt
	 * current date Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/
	public enum DATATYPE {
		number, varchar, character;
	}

	public String _getRandomString(DATATYPE type, int length) {
		String strType = type.toString();
		String defaultString = "";

		if (!strType.equalsIgnoreCase("number"))
			defaultString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

		if (!strType.equalsIgnoreCase("character"))
			defaultString = defaultString + "0123456789";

		StringBuilder strCh = new StringBuilder();
		Random rnd = new Random();

		for (int i = 0; i < length; i++)
			strCh.append(defaultString.charAt(rnd.nextInt(defaultString.length())));

		return strCh.toString();
	}

	/*******************************************************************
	 * Name : _alertHandler Description : Used to handle pop-up which comes up
	 * during execution Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/
	public void _alertHandler(WebDriver driver, String strOperation) {
		try {

			WebDriverWait wait = new WebDriverWait(driver, 300);
			Alert alert = wait.until(ExpectedConditions.alertIsPresent());

			// Accept or dismiss the alert
			switch (strOperation.toUpperCase()) {
			case "OK":
				alert.accept();
				driver.switchTo().defaultContent();
				log.info("Clicked on OK Button successfully");
				break;
			case "CANCEL":
				alert.dismiss();
				driver.switchTo().defaultContent();
				log.info("Clicked on CANCEL Button successfully");
				break;

			default:
				System.out.println("Pass the correct data either as 'OK' or 'CANCEL'");
				// Need to add custom report log and fail the test if needed
				System.exit(1);
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*******************************************************************
	 * Name : _closeWindow Description : Used to close popup windows which comes
	 * up during execution Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/
	public void _closeWindow(WebDriver driver) {
		String parentWindow = driver.getWindowHandle();

		for (String handle : driver.getWindowHandles()) {
			if (!handle.equals(parentWindow)) {
				driver.switchTo().window(handle);
				driver.close();
			}
		}
		driver.switchTo().window(parentWindow);
	}

	/*******************************************************************
	 * Name : _handleIMSecurityAlert Description : Used to handle windows
	 * authentication popup which comes up on clicking Alliance URL Modification
	 * Log : Date Initials Description of Modifications
	 * 
	 * @return
	 ********************************************************************/
	public void _handleIMSecurityAlert() throws InterruptedException {
		WebDriver driver = getCustumWebDriver();
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.alertIsPresent());

		driver.switchTo().alert().authenticateUsing(new UserAndPassword("UserId", "Password"));
		driver.switchTo().defaultContent();
	}

	/*******************************************************************
	 * Name : _compareSubStringCaseSensitive Description : Used to compare sub
	 * string with case sensitive Modification Log : Date Initials Description
	 * of Modifications
	 * 
	 * @return
	 ********************************************************************/
	public boolean _compareSubStringCaseSensitive(String strChar, String strSearchChar) {
		Boolean blnCondition = false;

		if (StringUtils.contains(strChar, strSearchChar)) {
			blnCondition = true;
		}

		return blnCondition;
	}

	/*******************************************************************
	 * Name : _compareSubStringIgnorecase Description : Used to compare sub
	 * string with Ignore Case Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/
	public boolean _compareSubStringIgnorecase(String strChar, String strSearchChar) {
		boolean blnCondition = false;

		if (StringUtils.containsIgnoreCase(strChar, strSearchChar)) {
			blnCondition = true;
		}

		return blnCondition;
	}

	/*******************************************************************
	 * Name : _compareStringCaseSensitive Description : Used to compare strings
	 * with Case sensitive Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/
	public boolean _compareStringCaseSensitive(String strChar, String strSearchChar) {
		Boolean blnCondition = false;

		if (strChar.equals(strSearchChar)) {
			blnCondition = true;
		}
		return blnCondition;
	}

	/*******************************************************************
	 * Name : _compareStringIgnorecase Description : Used to compare strings
	 * with Ignore Case Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/
	public boolean _compareStringIgnorecase(String strChar, String strSearchChar) {
		boolean blnCondition = false;

		if (strChar.equalsIgnoreCase(strSearchChar)) {
			blnCondition = true;
		}

		return blnCondition;
	}

	/*******************************************************************
	 * Name : _splitDatabyPosition Description : Used to split and return the
	 * data by position Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/

	public String _splitDatabyPosition(String strChar, int intStartPosition, int intEndPosition) {
		String strData = null;
		strData = strChar.substring(intStartPosition, intEndPosition);
		return strData;

	}

	/*******************************************************************
	 * Name : _splitDatabyDelimiter Description : Used to split the data by
	 * delimiter and return the data as an array Modification Log : Date
	 * Initials Description of Modifications
	 * 
	 * @return
	 ********************************************************************/

	public String[] _splitDatabyDelimiter(String strChar, String strDelimiter) {
		String[] strData;
		strData = strChar.split(strDelimiter);
		return strData;

	}

	/*******************************************************************
	 * Name : _getAttributeValue Description : Used to retrieve the data from
	 * application either by innerHTML or Value Modification Log : Date Initials
	 * Description of Modifications
	 * 
	 * @return
	 ********************************************************************/

	public String _getAttributeValue(Element element, String strAttribute) {
		String strApplicationValue = null;
		// Get the Attribute value
		strApplicationValue = element.getAttribute(strAttribute);
		return strApplicationValue;

	}

	/*******************************************************************
	 * Name : _takeScreenShot Description : Used to take screen shot and save in
	 * word document Modification Log : Date Initials Description of
	 * Modifications
	 * 
	 * @return
	 ********************************************************************/

	/*public void _takeScreenShot(WebDriver driver, String strOperation, String strTextEntry, String docName) {
		try {

			switch (strOperation.toUpperCase()) {
			case "START":
				doc = new XWPFDocument();
				p = doc.createParagraph();
				r = p.createRun();
				reqScreens = "Screenshots Initiated";
				log.info("Taking screenshot initiated");
				break;
			case "PRINT":
				if (reqScreens.equalsIgnoreCase("Screenshots Initiated")) {
					File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					pic = new FileInputStream(scrFile);

					r.addBreak();
					r.setText(strTextEntry);
					r.addBreak();
					r.addPicture(pic, XWPFDocument.PICTURE_TYPE_PNG, "", Units.toEMU(400), Units.toEMU(300));
					r.addBreak();

					log.info("Screenshot taken successfully");
				}
				break;
			case "FINISH":
				if (reqScreens.equalsIgnoreCase("Screenshots Initiated")) {
					screenShotWordDocPath = DeviceManager.instance().getConfigurationProperties()
							.getProperty("screenshot.path") + "\\" + docName + ".docx";
					FileOutputStream out = new FileOutputStream(screenShotWordDocPath);
					doc.write(out);
					out.close();
					pic.close();

					log.info("Screenshot saved successfully");
					// CustomReporting.instance().logInfo("Screenshot: ", " ",
					// "", "<a href=\"" + screenShotWordDocPath + "\"" + ">Click
					// here to view screenprints</a>");
				}
				break;

			default:
				System.out.println("Please pass the correct operation string");
				// System.exit(1);
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}*/
	
	public void _takeScreenShot(WebDriver driver, String strOperation, String strTextEntry, String docName) {
		try {

			switch (strOperation.toUpperCase()) {
			case "START":
				doc = new XWPFDocument();
				p = doc.createParagraph();
				r = p.createRun();
				reqScreens = "Screenshots Initiated";
				log.info("Taking screenshot initiated");
				break;
			case "PRINT":
				if (reqScreens.equalsIgnoreCase("Screenshots Initiated")) {
					/*File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
					pic = new FileInputStream(scrFile);

					r.addBreak();
					r.setText(strTextEntry);
					r.addBreak();
					r.addPicture(pic, XWPFDocument.PICTURE_TYPE_PNG, "", Units.toEMU(400), Units.toEMU(300));
					r.addBreak();*/

					log.info("Screenshot taken successfully");
					
					Rectangle captureSize=new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
					Robot robot=new Robot();
					BufferedImage bufferedImage=robot.createScreenCapture(captureSize);
					//pic = new FileInputStream(bufferedImage);
					ByteArrayOutputStream os = new ByteArrayOutputStream();
					
					ImageIO.write(bufferedImage, "PNG", os);
					InputStream is = new ByteArrayInputStream(os.toByteArray());
					
					r.addBreak();
					r.setText(strTextEntry);
					r.addBreak();
					r.addPicture(is, XWPFDocument.PICTURE_TYPE_PNG, "", Units.toEMU(400), Units.toEMU(300));
					
					r.addBreak();
				}
				break;
			case "FINISH":
				if (reqScreens.equalsIgnoreCase("Screenshots Initiated")) {
					screenShotWordDocPath = DeviceManager.instance().getConfigurationProperties()
							.getProperty("screenshot.path") + "\\" + docName + ".docx";
					FileOutputStream out = new FileOutputStream(screenShotWordDocPath);
					doc.write(out);
					out.close();
					//pic.close();

					log.info("Screenshot saved successfully");
					//CustomReporting.instance().logInfo("Screenshot: ", " ","", "<a href=\"" + screenShotWordDocPath + "\"" + ">Click here to view screenprints</a>");
					CustomReporting.instance().logReport("<a href=\"" + screenShotWordDocPath + "\"" + ">Click here to view screenprints</a>");
				}
				break;

			default:
				System.out.println("Please pass the correct operation string");
				// System.exit(1);
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void _uploadFile(String FilePath )
    {
		  long startTime = System.currentTimeMillis();
          try
          {
        	         	  
          Toolkit toolkit=Toolkit.getDefaultToolkit();
          Clipboard clipboard=toolkit.getSystemClipboard();
          StringSelection ss=new StringSelection(FilePath);
          clipboard.setContents(ss, ss);
          String result=(String) clipboard.getData(DataFlavor.stringFlavor);
          System.out.println("string from the clipboard "+result);
          Thread.sleep(5000);
          
          Robot robot = new Robot();
          robot.keyPress(KeyEvent.VK_ALT);
          robot.keyPress(KeyEvent.VK_N);
          robot.keyRelease(KeyEvent.VK_ALT);
          robot.keyRelease(KeyEvent.VK_N);
          Thread.sleep(5000);
          robot.keyPress(KeyEvent.VK_CONTROL);
          robot.keyPress(KeyEvent.VK_V);
          robot.keyRelease(KeyEvent.VK_V);
          robot.keyRelease(KeyEvent.VK_CONTROL);
          Thread.sleep(5000);
          robot.keyPress(KeyEvent.VK_ENTER);
          robot.keyRelease(KeyEvent.VK_ENTER);
          
          Thread.sleep(8000);
          
          CustomReporting.logReport("","", "File uploaded successfully",StepStatus.SUCCESS,new String[] { },startTime);
          }
          catch(Exception ex)
          {
        	  CustomReporting.logReport("","", "File upload failed","", StepStatus.FAILURE,
  					new String[] {  }, startTime, ex);
        	  System.out.println(ex);
          }
    }
	
	public void _launchOutlook( ) throws URISyntaxException
    {
		try {
		      //Desktop.getDesktop().mail( new URI( "mailto:javaexamplecenter@gmail.com?subject=Test%20message" ) );
		      //Desktop.getDesktop().mail( );
		      Runtime.getRuntime().exec("C:\\Program Files (x86)\\Microsoft Office\\Office14\\OUTLOOK.exe");
		     } 
		catch ( IOException ex )
		    {
		    } 
    }
	
	public void _writeToExcel(String Sheetname,String strColName,String strVal,String strTCID)
    {
		long startTime = System.currentTimeMillis();
    try {
      
      String writeExcelPath = DeviceManager.instance().getConfigurationProperties().getProperty("data.path");
      FileInputStream file = new FileInputStream(new File(writeExcelPath));
     
      XSSFWorkbook  workbook = new XSSFWorkbook (file);
      XSSFSheet sheet = workbook.getSheet(Sheetname);
      int intRow=findExcelRow(sheet,strTCID);
      int intCol=findExcelCol(sheet,strColName);
      sheet.getRow(intRow).createCell(intCol).setCellValue(strVal);
      
      FileOutputStream outFile =new FileOutputStream(new File(writeExcelPath));
      workbook.write(outFile);
      file.close();
      outFile.close();
      CustomReporting.logReport("","", strVal+" : written to Excel Successfully",StepStatus.SUCCESS,new String[] {},startTime);

  } catch (FileNotFoundException e) {
      e.printStackTrace();
      CustomReporting.logReport("","", strVal+" : writing to Excel failed","", StepStatus.FAILURE,
				new String[] {}, startTime, e);
  	  
  } catch (IOException e) {
      e.printStackTrace();
      CustomReporting.logReport("","", strVal+" : writing to Excel failed","", StepStatus.FAILURE,
				new String[] { }, startTime, e);
  
  }

}
	
	public int findExcelCol(XSSFSheet sheet, String strColName)
	{
		int colNum=0;
		try {

			
			String colVal=sheet.getRow(0).getCell(colNum).getStringCellValue();
			
			while(!colVal.isEmpty()){
				if(colVal.equalsIgnoreCase(strColName)){
					break;
				}
				else
				{
				   colNum=colNum+1;
				   colVal=sheet.getRow(0).getCell(colNum).getStringCellValue();
				}

			}
						   
		    
		} catch (Exception e) {
			e.printStackTrace();
            
        }
		
		return colNum;
	}


	public int findExcelRow(XSSFSheet sheet, String strTCID)
	{
		int intRowNum=0;
		try {

			int numRow=sheet.getLastRowNum();		
			
			for(int i=0;i<=numRow;i++){
				 
				String cellVal=sheet.getRow(i).getCell(0).getStringCellValue();
				if (!cellVal.isEmpty() && cellVal.contains(strTCID)){
					break;
				}
				else
				{
					intRowNum=intRowNum+1;
				}
			 
			  }
		   
		    
		} catch (Exception e) {
			e.printStackTrace();
            
        }
		
		return intRowNum;
	}
	
	
}
