package com.everest.webservice.clearsubmission.spi;

import org.json.JSONObject;
import org.testng.asserts.SoftAssert;
import org.xframium.page.StepStatus;

import com.everest.utility.CustomAbstractPage;
import com.everest.utility.CustomReporting;
import com.everest.webservice.WebService;
import com.everest.webservice.clearsubmission.WebServiceClearSubmission;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

import static com.jayway.restassured.RestAssured.*;
import static com.jayway.restassured.response.Response.*;
import static com.jayway.restassured.specification.RequestSpecification.*;

public class WebServiceClearSubmissionImpl extends CustomAbstractPage implements WebServiceClearSubmission{

		
	@Override
	public void updateSubmission (String tcID, SoftAssert softAssert) throws Exception{
		long startTime = System.currentTimeMillis();	
		//getWebDriver().close();
		
		
		Response response = given().
				header("Authorization", "Q2xlYXJTdWJtaXNzaW9uU2VydmljZTtDbGVhclN1Ym1pc3Npb247RVNVSW50VXNlcjtFU1U7MS4w").
				contentType("application/xml").
				body("D:\\Users\\tejaz\\Desktop\\Selenium\\POC\\PayLoad.xml").
				when().
				post("https://esbdev.everestre.net:7843/services/GenericUpdateSubmissionService/2.0");
		
		/*Response response = given().
				//header("Authorization", "Q2xlYXJTdWJtaXNzaW9uU2VydmljZTtDbGVhclN1Ym1pc3Npb247RVNVSW50VXNlcjtFU1U7MS4w").
				contentType("application/xml").
				body("D:\\Users\\tejaz\\Desktop\\Selenium\\POC\\PayLoad2.xml").
				when().
				post("http://del.icio.us/api/peej/bookmarks/");*/

		
		System.out.println(response.asString());
		CustomReporting.logReport("","","WebService response for Delicious service : "+response.asString(),StepStatus.SUCCESS, new String[] {},startTime);
		
	}
	
	@Override
	public void clearOFACService (String tcID, SoftAssert softAssert) throws Exception{
		long startTime = System.currentTimeMillis();	
		getWebDriver().close();
		

		RequestSpecification requestSpecification=RestAssured.given();
		requestSpecification.header("Authorization","Q2xlYXJPRkFDU2VydmljZTtDbGVhck9GQUM7RVNCRGV2VXNlcjtFU0I7MS4wO0V4Y2Vzc0dMX0RldjY=");
		requestSpecification.headers("content-type","application/json");
		//requestSpecification.body(jsonObj.toString());
		requestSpecification.body("{\"ESCAPEREST\":{\"Account\":{\"InsuredName\":\"Dawood Ibrahim\"}}}");
		
		Response response=requestSpecification.post("http://esbdev:7802/service/GenericRestClearOFACService");
		
		System.out.println(response.asString());
		
		CustomReporting.logReport("","","WebService response for ClearOFACService : "+response.asString(),StepStatus.SUCCESS,new String[] {},startTime);
		
	}
	
}
