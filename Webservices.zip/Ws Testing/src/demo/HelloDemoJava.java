package demo;

import org.openqa.selenium.Point;

import utility.TestBase;

public class HelloDemoJava extends TestBase{

	public static void main(String[] args) throws InterruptedException {
		launchChrome();
		
		
		driver.manage().window().setPosition(new Point(-2000, 0));
		
		Thread.sleep(5000);
		
		maximize();
		
		

	}

}
