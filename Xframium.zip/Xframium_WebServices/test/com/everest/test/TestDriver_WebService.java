/*******************************************************************
*	Name              :	Renters_Driver
*	Description       : Driver class for Renters Quote-NB LOB
*	Author            : Infosys 
*	Date Created      :	11/22/2016
*	Modification Log  :                                                     
*	Date		Initials     	Description of Modifications 
********************************************************************
********************************************************************/
package com.everest.test;

import org.testng.annotations.Test;
import org.xframium.spi.Device;

import com.everest.functions.GenericFunctions;
//import com.alliance.utility.TestMatrixGenarator;
import com.everest.functions.settings.Setup;
import com.everest.utility.CustomAbstractPage;
import com.everest.utility.CustomAbstractTest;
import org.xframium.page.data.PageData;
import com.everest.utility.CustomReporting;
import com.everest.webservice.clearsubmission.spi.ClearSubmissionImplInvoker;
import com.everest.webservice.spi.PageImplInvoker;

import org.testng.asserts.SoftAssert;

public class TestDriver_WebService extends CustomAbstractTest {	
	
	@Test( dataProvider = "DeviceManager")
	public void Demo (TestName testName, Device device) throws Exception 
    {		
		try{ 							
 	
			SoftAssert softAssert= new SoftAssert();
 			String tcID = getTestName(testName);
 			GenericFunctions.instance()._addToGlobalVariableList("gvTestName", testName.toString());
 			
 			//PageImplInvoker classInvoker = new PageImplInvoker();
 			//classInvoker.createSubmission("info.bhanupratap@gmail.com","APP","password",tcID);
 			
 			ClearSubmissionImplInvoker invoke=new ClearSubmissionImplInvoker();
 			
 			invoke.clearOFACService(tcID);
 			
 			invoke.updateSubmission(tcID);
 	 	    	
 	    	softAssert.assertAll();
 	    	
 			System.out.println("Completed");
 	     }
		catch(Exception ex){   
        	
        	CustomReporting.logReport(ex);
        	ex.printStackTrace();    
        	throw ex;
        }	
    }
	
	
	
	
}

