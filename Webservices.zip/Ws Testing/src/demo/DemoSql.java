package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DemoSql {

	public static String dburl = "jdbc:sqlserver://enicdb-dev\\ENIC_QA;databaseName=EscapeDB;integratedSecurity=true";
	public static String dbUserName = "";
	public static String dbPassword = "";

	public static String SubmissionNumberbr = "939855";

	public static void verifyInDatabase(String SubmissionNumberbr) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection con = DriverManager.getConnection(dburl, dbUserName, dbPassword);

		Statement stmt = con.createStatement();
		String query = "select Submission_Nbr from SUB_Submission order by Submission_Nbr desc";
		ResultSet res = stmt.executeQuery(query);

		boolean flag = false;
		String actualSubmissionNumberbr="";

		try {
			while (res.next()) {
				// System.out.print(res.getString(1)+"\t");
					// }
			if (SubmissionNumberbr.equals(res.getString(1))) {
				actualSubmissionNumberbr=res.getString(1);
				flag = true;
				break;
			}
			}// end of while loop
		} catch (Exception e) {
			e.printStackTrace();
		} // end of catch method
		finally {
			if (flag) {
				System.out.println("\nGiven Submission Number -> "+SubmissionNumberbr+" matches with " + actualSubmissionNumberbr + " in Escape Database");
			} else {
				System.out.println("\nGiven Submission Number -> " + SubmissionNumberbr + " Not Found in the Escape Database");
			}
			// Close DB connection
			if (con != null) {
				con.close();
			}
		} // end of finally block

	} // end of method

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		verifyInDatabase(SubmissionNumberbr);
	}

}
