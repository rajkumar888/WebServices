package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import static com.jayway.restassured.RestAssured.given;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

public class WebServiceClearSubmission {
	WebDriver driver;
	
	// @Test
	public void testClearSubmission() throws IOException {

		System.out.println("\nTest Case ClearSubmission\n");
		String uri="http://esbint.everestre.net:7802/services/GenericClearSubmissionService";
		String fpath="D:\\Users\\rsingh\\Desktop\\ClearSubmission\\Payload_ClearSubmissionPankaj.xml" ;
		
		String content = new String(Files.readAllBytes(Paths.get(fpath)));
		// System.out.println(content);
		
		RequestSpecification requestSpecification = RestAssured.given();
		requestSpecification.header("Authorization","Q2xlYXJTdWJtaXNzaW9uU2VydmljZTtDbGVhclN1Ym1pc3Npb247RVNVSW50VXNlcjtFU1U7MS4w");

		// requestSpecification.headers("content-type","application/xml");
		//requestSpecification.headers("Content-Type", "application/XML; charset=utf-8");
		
		requestSpecification.contentType(ContentType.XML);
		requestSpecification.body(content);

		Response response = requestSpecification.post(uri);
		
		System.out.println();
		System.out.println(response.getStatusCode());
		System.out.println(response.contentType());
		System.out.println(response.asString());
	}

	//@Test
		public void ClearSubmissiondev() throws IOException {
			System.out.println("\nTest Case ClearSubmissiondev\n");
			String uri="http://esbdev.everestre.net:7802/services/GenericClearSubmissionService";
			String fpath="D:\\Users\\rsingh\\Desktop\\ClearSubmission\\Payload_ClearSubmissionPankaj.xml" ;
			
			String myRequest = new String(Files.readAllBytes(Paths.get(fpath)));
			//System.out.println(myRequest);
			
			Response response = given()
					.contentType(ContentType.XML)
					.header("Authorization", "Q2xlYXJTdWJtaXNzaW9uU2VydmljZTtDbGVhclN1Ym1pc3Npb247RVNVSW50VXNlcjtFU1U7MS4w")
					.body(myRequest)
					.post(uri);
			
			System.out.println();
			System.out.println(response.getStatusCode());
			System.out.println(response.contentType());
			System.out.println(response.asString());

		}
	
	 
	@Test
	public void ClearSubmissionint() throws IOException, Throwable {
		System.out.println("\nTest Case ClearSubmissionint\n");
		String uri="http://esbint.everestre.net:7802/services/GenericClearSubmissionService";
		String fpath="D:\\Users\\rsingh\\Desktop\\ClearSubmission\\Payload_ClearSubmissionPankaj.xml" ;
		
		String myRequest = new String(Files.readAllBytes(Paths.get(fpath)));
		//System.out.println(myRequest);
		
		Response response = given()
				.contentType(ContentType.XML)
				.header("Authorization", "Q2xlYXJTdWJtaXNzaW9uU2VydmljZTtDbGVhclN1Ym1pc3Npb247RVNVSW50VXNlcjtFU1U7MS4w")
				.body(myRequest)
				.post(uri);
		
				System.out.println();
				System.out.println(response.getStatusCode());
				System.out.println(response.contentType());
				System.out.println(response.asString());
		
				DocumentBuilder newDocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				Document parse = newDocumentBuilder.parse(new ByteArrayInputStream(response.asString().getBytes()));
	      
	      String SubmissionNumberbr=parse.getElementsByTagName("SubmissionNbr").item(0).getTextContent();
	      String AccountNumber=parse.getElementsByTagName("AccountNbr").item(0).getTextContent();
	            
      System.out.println(SubmissionNumberbr+"\n"+AccountNumber);
      
      
      ChromeOptions Options = new ChromeOptions();
      Options.addArguments("test-type");
      Options.addArguments("disable-infobars"); 
      Options.addArguments("start-maximized");
      Options.addArguments("--js-flags=--expose-gc");  
      Options.addArguments("--enable-precise-memory-info"); 
      Options.addArguments("--disable-popup-blocking");
      Options.addArguments("--disable-default-apps"); 
      driver = new ChromeDriver(Options);
      
    
      String escapeUrl="http://everestnational-qa/ESCAPE/Default.aspx";
      
      driver.get(escapeUrl);
      
      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      
      driver.findElement(By.xpath("html/body/form/div[3]/table/tbody/tr[6]/td[2]/table/tbody/tr/td/table/tbody/tr[3]/td[1]/table/tbody/tr[2]/td/table/tbody/tr[1]/td/table/tbody/tr[3]/td[2]/input")).sendKeys("tseelam");
      
      driver.findElement(By.xpath("html/body/form/div[3]/table/tbody/tr[6]/td[2]/table/tbody/tr/td/table/tbody/tr[3]/td[1]/table/tbody/tr[2]/td/table/tbody/tr[1]/td/table/tbody/tr[4]/td[2]/input")).sendKeys("Tulsi@30");
      
      driver.findElement(By.xpath("//*[@id='LoginButton']")).click();
      
      driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_tbSubmissionNumber']")).sendKeys(SubmissionNumberbr);
      
      driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_btnSearch']")).click();
      
	}

}	// end of class
