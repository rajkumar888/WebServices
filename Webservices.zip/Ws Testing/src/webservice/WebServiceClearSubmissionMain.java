package webservice;

import org.testng.annotations.Test;
import org.w3c.dom.Document;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.jayway.restassured.http.ContentType;
import static com.jayway.restassured.RestAssured.given;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import com.jayway.restassured.response.Response;
import utility.TestBase;

public class WebServiceClearSubmissionMain extends TestBase {
	public static String uri = "http://esbint.everestre.net:7802/services/GenericClearSubmissionService";

	public static String authval = "Q2xlYXJTdWJtaXNzaW9uU2VydmljZTtDbGVhclN1Ym1pc3Npb247RVNVSW50VXNlcjtFU1U7MS4w";
	public static String authkey = "Authorization";

	@Test(priority = 1)
	public void ClearSubmissionIntEnvPositive() throws IOException, Throwable {
		System.out.println("ClearSubmissionIntEnvPositive started .......");
		System.out.println("===============================================================");

		test = extent.createTest("ClearSubmissionIntEnvPositive");

		String requestFilePath = "./src/DataSourceFiles/Payload_ClearSubmission1.xml";

		String request = new String(Files.readAllBytes(Paths.get(requestFilePath)));
		// System.out.println(request);

		Response response = given()
				.contentType(ContentType.XML)
				.header(authkey, authval)
				.body(request).when()
				.post(uri);

		System.out.println(response.getStatusCode());
		System.out.println(response.contentType());
		System.out.println(response.asString());

			if (response.getStatusCode() == 200) {
			response.then().statusCode(200).log().all();

			DocumentBuilder newDocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document parse = newDocumentBuilder.parse(new ByteArrayInputStream(response.asString().getBytes()));

			String SubmissionNumberbr = parse.getElementsByTagName("SubmissionNbr").item(0).getTextContent();
			String AccountNumber = parse.getElementsByTagName("AccountNbr").item(0).getTextContent();

			System.out.println("Submission Numer => " + SubmissionNumberbr + "\nAccount Nubmer = > " + AccountNumber);

			verifyInEscape(SubmissionNumberbr); // calling of escape portal for verification
			test.log(Status.INFO, MarkupHelper.createLabel("Submission Number "+SubmissionNumberbr + " Successfully verified in Escapre WebPortal", ExtentColor.GREEN));
			verifyInDatabase(SubmissionNumberbr); // calling of escape portal for verification
			test.log(Status.INFO, MarkupHelper.createLabel("Submission Number "+SubmissionNumberbr + " Successfully verified in Escapre Database", ExtentColor.GREEN));
		} 	// end of if block
			else {
			response.then().statusCode(200).log().all();
			}
	}

	//@Test(priority = 2)
	public void ClearSubmissionIntEnvNegative() throws IOException, Throwable {

		System.out.println("ClearSubmissionIntEnvNegative Started .......");
		System.out.println("===============================================================");

		test = extent.createTest("ClearSubmissionIntEnvNegative");
		
		//test = extent.createTest(getClass().getName()+ ":"+method.getName()); 

		String requestFilePath = "./src/DataSourceFiles/Payload_ClearSubmission4.xml";

		String request = new String(Files.readAllBytes(Paths.get(requestFilePath)));
		// System.out.println(request);

		Response response = given()
				.contentType(ContentType.XML)
				.header(authkey, authval)
				.body(request).when()
				.post(uri);

		System.out.println(response.getStatusCode());
		System.out.println(response.contentType());
		System.out.println(response.asString());

		
		if (response.getStatusCode() == 200) {
			response.then().statusCode(200).log().all();

			DocumentBuilder newDocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document parse = newDocumentBuilder.parse(new ByteArrayInputStream(response.asString().getBytes()));

			String SubmissionNumberbr = parse.getElementsByTagName("SubmissionNbr").item(0).getTextContent();
			String AccountNumber = parse.getElementsByTagName("AccountNbr").item(0).getTextContent();

			System.out.println("Submission Numer => " + SubmissionNumberbr + "\nAccount Nubmer = > " + AccountNumber);

			verifyInEscape(SubmissionNumberbr); // calling of escape portal for verification
			verifyInDatabase(SubmissionNumberbr); // calling of escape portal for verification 
		} else {
			response.then().statusCode(200).log().all();
		}

		}// end of ClearSubmissionIntEnvNegative
} // end of class
