package com.everest.webservice.spi;



import org.json.JSONObject;
import org.testng.asserts.SoftAssert;
import org.xframium.page.StepStatus;

import com.everest.utility.CustomAbstractPage;
import com.everest.utility.CustomReporting;
import com.everest.webservice.WebService;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;


public class WebServiceImpl extends CustomAbstractPage implements WebService{

		
	@Override
	public void login (String loginId,String loginSource, String password,String tcID, SoftAssert softAssert) throws Exception{
		long startTime = System.currentTimeMillis();		
		getWebDriver().close();	
		
		LoginPojo loginpojo=new LoginPojo();

		Login login=new Login();
		login.setLoginId(loginId);
		login.setLoginSource(loginSource);
		login.setPassword(password);

		loginpojo.setLogin(login);
		JSONObject jsonObj=new JSONObject(loginpojo);

		RequestSpecification requestSpecification=RestAssured.given();
		requestSpecification.headers("content-type","application/json");
		requestSpecification.body(jsonObj.toString());
		Response response=requestSpecification.post("http://www.fashionandyou.com/api/login/business?operationType=login");
		System.out.println(response.asString());
		CustomReporting.logReport("","","WebService response : "+response.asString(),StepStatus.SUCCESS,new String[] {},startTime);
		
	}
	
}
